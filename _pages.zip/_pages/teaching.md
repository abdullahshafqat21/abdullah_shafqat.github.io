---
layout: archive
title: "Teaching"
permalink: /teaching/
author_profile: true
redirect_from: 
  - /md/
  - /teaching.html
---

<!-- If you have many teaching posts in /_teaching/, used layout class defined in /_includes/archive-single.html

{% for post in site.teaching reversed %}
  {% include archive-single.html %}
{% endfor %} -->


### Graduate courses
* Instructor in course 1
  * description
  * Autumn 20xx - Spring 20xx, 4 lectures
  * Department xx, University xx

* Teaching assistant in course 2
  * description
  * Autumn 20xx - Spring 20xx, 4 lectures
  * Department xx,  University xx

* Lecturer in course 2
  * description
  * Autumn 20xx - Spring 20xx, 4 lectures
  * Department xx,  University xx


### Undergraduate course
* Teaching assistant in course 2
  * description
  * Autumn 20xx - Spring 20xx, 4 lectures
  * Department xx,  University xx
