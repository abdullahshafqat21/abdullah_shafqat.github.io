---
permalink: /contact/
title: "Contact"
author_profile: true
redirect_from: 
  - /md/
  - /contact.html
---

#### Write me an email! 
<i class="si si-gmail"></i> [Gmail](mailto:abdullah.shafqat@tu-darmstadt.de)


#### See more about me on
<i class="si si-googlescholar"></i> [Google Scholar](https://scholar.google.com/citations?user=zgqDWcwAAAAJ&hl=de),
<i class="si si-researchgate"></i> [ResearchGate](https://www.researchgate.net/profile/Abdullah-Shafqat?ev=hdr_xprf), 

<i class="si si-orcid"></i> [ORCID](https://orcid.org/0009-0006-2612-0686),

<i class="si si-linkedin"></i> [Linkedin](https://www.linkedin.com/in/abdullah-shafqat-45069a135), 
<i class="si si-github"></i> [Github](https://github.com/abdullahshafqat21),

<i class="si si-internetarchive"></i> [Mechanics of Funcional Materials, Technical University of Darmstadt](https://www.mawi.tu-darmstadt.de/mfm/mechanics_of_functional_materials/mfm_staff/mfm_staff_details_141248.en.jsp).

